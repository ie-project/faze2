package ir.asta.training.contacts.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;

@Entity
@Table(name="users")
public class UserEntity {

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;


    //email
    @Column(name = "email")
    private String email;
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    //role
    @Column(name = "role")
    private String role;
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }


    //firstName
    @Column(name = "firstName")
    private String firstName;
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    //lastName
    @Column(name = "lastName")
    private String lastName;
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //passWord
    @Column(name = "password")
    @JsonIgnore
    private String password;

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    //repeatPass
    @Column(name = "repeatPass")
    @JsonIgnore
    String repeatPass;
    public String getRepeatPass() {
        return repeatPass;
    }
    public void setRepeatPass(String repeatPass) {
        this.repeatPass = repeatPass;
    }



    @Column(name = "token")
    private String token;
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

}
