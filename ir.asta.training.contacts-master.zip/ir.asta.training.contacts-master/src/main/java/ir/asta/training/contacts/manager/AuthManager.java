package ir.asta.training.contacts.manager;

import ir.asta.training.contacts.dao.AuthDAO;
import ir.asta.training.contacts.entities.CaseEntity;
import ir.asta.training.contacts.entities.UserEntity;
import ir.asta.wise.core.datamanagement.ActionResult;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;

@Named("authManager")
public class AuthManager {

    @Inject
    private AuthDAO dao;

    @Transactional
    public ActionResult<UserEntity> register(String email, String role, String firstName,
                                             String lastName, String password, String repeatPass) throws UnsupportedEncodingException, NoSuchAlgorithmException
    {
        String token = generateToken();
        ActionResult<UserEntity> result = new ActionResult<>();
        if (!dao.containsUser(email)){
            if (!isValid(email) || password.length()<8)
            {
                result.setSuccess(false);
                if (!isValid(email))
                result.setMessage("email format is not valid!");
                else if(password.length()<8)
                    result.setMessage("password must have more than 8 characters!");
            }

            else
            {
            result.setData(dao.register(email, role, firstName, lastName, hashPassword(password), repeatPass ,token));
            result.setSuccess(true);
            }
        }
        else
            result.setMessage("user already exist!");
        return result;
    }

    public ActionResult<UserEntity> login(String email ,String password) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        UserEntity entity = dao.checkUserPass(email,hashPassword(password));
        ActionResult<UserEntity> result = new ActionResult<>();
        if (entity != null){
            result.setSuccess(true);
            result.setData(entity);
        }
        else{
            result.setMessage("Email or password is incorrect!"  );
        }
        return result;
    }

    @Transactional
    public ActionResult<CaseEntity> setCase(String subject,String whoToSend,String message,String status,String time,String token)
    {
        CaseEntity entity= dao.setCase(subject,whoToSend,message,status,time,token);
        ActionResult<CaseEntity> result = new ActionResult<>();

           if (entity !=null){
               result.setSuccess(true);
                result.setData(entity);
           }
           return result;
    }





    @Transactional
    public ActionResult<UserEntity> editPro(String email, String firstName,
                                             String lastName, String newPassword, String repeatPass) throws UnsupportedEncodingException, NoSuchAlgorithmException
    {
        UserEntity userFromDb = dao.findUser(email);
        userFromDb.setEmail(email);
        userFromDb.setFirstName(firstName);
        userFromDb.setLastName(lastName);
        userFromDb.setPassword(newPassword);
        userFromDb.setRepeatPass(repeatPass);
        dao.updatePro(userFromDb);

        ActionResult<UserEntity> result = new ActionResult<>();
        result.setSuccess(true);
        result.setMessage("editing your information done successful!");
        result.setData(dao.updatePro(userFromDb));
        return result;

    }


    @Transactional
    public ActionResult<List> seeCases(String token) throws UnsupportedEncodingException, NoSuchAlgorithmException {

        List list = dao.seeCases(token);
        ActionResult<List> result = new ActionResult<>();
        if (result != null){
            result.setSuccess(true);
        result.setData(list);}
        return result;

    }


    @Transactional
    public ActionResult<List> seeAllCases() throws UnsupportedEncodingException, NoSuchAlgorithmException {

        List list = dao.seeAllCases();
        ActionResult<List> result = new ActionResult<>();
        if (result != null){
            result.setSuccess(true);
            result.setData(list);}
        else
            result.setMessage("you dont have any reference!");
        return result;

    }


    @Transactional
    public ActionResult<String> seeSender(String token) throws UnsupportedEncodingException, NoSuchAlgorithmException {

        String lastName = dao.seeSender(token);
        ActionResult<String> result = new ActionResult<>();
        if (result != null){
            result.setSuccess(true);
            result.setData(lastName);}
        else
            result.setMessage("not found!");
        return result;

    }

    private String hashPassword(String password) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        return new String(hash,"UTF-8");
    }

    public String generateToken(){
        String token="";
        Random random = new Random();
        for (int i = 0; i < 30; i++) {
            int anInt = random.nextInt(26);
            char ch = (char) ('a' + anInt);
            token += ch;
        }
        return token;
    }

    static boolean isValid(String email) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(regex);
    }


}
