package ir.asta.training.contacts.manager;

import ir.asta.training.contacts.dao.AuthDAO;
import ir.asta.training.contacts.entities.UserEntity;
import ir.asta.wise.core.datamanagement.ActionResult;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

@Named("authNamed")
public class AuthManager {

    @Inject
    private AuthDAO dao;

    @Transactional
    public ActionResult<UserEntity> register(String email, String role, String firstName,
                                             String lastName, String password, String repeatPass,String token) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        ActionResult<UserEntity> result = new ActionResult<>();
        if (!dao.containsUser(email)){
            result.setData(dao.register(email, role, firstName, lastName, hashPassword(password), repeatPass ,token));
            result.setSuccess(true);
        }
        else
            result.setMessage("user dos'nt exist");
        return result;
    }

    public ActionResult<UserEntity> login(String email ,String password) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        UserEntity entity = dao.checkUserPass(email,hashPassword(password));
        ActionResult<UserEntity> result = new ActionResult<>();
        if (entity != null){
            result.setSuccess(true);
            result.setData(entity);
        }
        else
            result.setMessage("Email or password is incorrect");
        return result;
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException, UnsupportedEncodingException {
//        MessageDigest digest = MessageDigest.getInstance("SHA-256");
//        byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
//        return new String(hash,"UTF-8");

        final MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] result = digest.digest(password.getBytes());
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < result.length; i++) {
            sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString();
    }

    public String generateToken(){
        String token="";
        Random random = new Random();
        for (int i = 0; i < 30; i++) {
            int anInt = random.nextInt(26);
            char ch = (char) ('a' + anInt);
            token += ch;
        }
        return token;
    }

}
