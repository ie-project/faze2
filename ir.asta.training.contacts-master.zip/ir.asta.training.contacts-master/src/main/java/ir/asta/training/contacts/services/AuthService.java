package ir.asta.training.contacts.services;

import ir.asta.training.contacts.entities.UserEntity;
import ir.asta.wise.core.datamanagement.ActionResult;
import org.apache.cxf.jaxrs.ext.PATCH;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.awt.*;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

@Path("/auth")
public interface AuthService {
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/register") //check shavad
    public ActionResult<UserEntity> register(@FormParam("email") String email,
                                 @FormParam("role") String role,
                                 @FormParam("firstName")String firstName,
                                 @FormParam("lastName")String lastName,
                                 @FormParam("password")String password,
                                 @FormParam("repeatPass")String repeatPass,
                                 @FormParam("token")String token)
        throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login") //check shavad
    public ActionResult<UserEntity> login(@FormParam("email") String email,
                                          @FormParam("password")String password
                                         ) throws UnsupportedEncodingException, NoSuchAlgorithmException;

}

