package ir.asta.training.contacts.services;

import ir.asta.training.contacts.entities.CaseEntity;
import ir.asta.training.contacts.entities.UserEntity;
import ir.asta.wise.core.datamanagement.ActionResult;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@Path("/auth")
public interface AuthService {
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/register")
    public ActionResult<UserEntity> register(@FormParam("email") String email,
                                 @FormParam("role") String role,
                                 @FormParam("firstName")String firstName,
                                 @FormParam("lastName")String lastName,
                                 @FormParam("password")String password,
                                 @FormParam("repeatPass")String repeatPass)
        throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login")
    public ActionResult<UserEntity> login(@FormParam("email") String email,
                                          @FormParam("password")String password)
        throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/setCase")
    public ActionResult<CaseEntity> setCase(@FormParam("subject") String subject,
                                            @FormParam("whoToSend")String whoToSend,
                                            @FormParam("message") String message,
                                            @FormParam("status") String status,
                                            @FormParam("time") String time,
                                            @FormParam("token") String token)
        throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/editPro")
    public ActionResult<UserEntity> editPro(@FormParam("email") String email,
                                            @FormParam("firstName")String firstName,
                                            @FormParam("lastName")String lastName,
                                            @FormParam("newPassword")String password,
                                            @FormParam("repeatPass")String repeatPass)
            throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/seeCases")
    public ActionResult<List> seeCases(@FormParam("token") String token)
            throws UnsupportedEncodingException, NoSuchAlgorithmException;



    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/seeAllCases")
    public ActionResult<List> seeAllCases()
            throws UnsupportedEncodingException, NoSuchAlgorithmException;


    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/seeSender")
    public ActionResult<String> seeSender(@FormParam("token") String token)
            throws UnsupportedEncodingException, NoSuchAlgorithmException;

}

