package ir.asta.training.contacts.entities;

import javax.persistence.*;

@Entity
@Table(name = "cases")
public class CaseEntity {


    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }


    @Column(name = "subject")
    private String subject;
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }



    @Column(name = "whoToSend")
    private String whoToSend;
    public String getWhoToSend() {
        return whoToSend;
    }
    public void setWhoToSend(String whoToSend) {
        this.whoToSend = whoToSend;
    }



    @Column(name = "message")
    private String message;
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }


    @Column(name = "status")
    private String status;
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name = "time")
    private String time;
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }


    @Column(name = "token")
    private String token;
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

}
