package ir.asta.training.contacts.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name="users")
public class UserEntity {


    String email;
    String role;
    String firstName;
    String lastName;
    //@JsonIgnore
    String password;
    String repeatPass;


    //email
    @Id
    @Column(name = "email")
    @GeneratedValue(strategy=GenerationType.AUTO)
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    //role
    @Column(name = "role")
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }


    //firstName
    @Column(name = "firstName")
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    //lastName
    @Column(name = "lastName")
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //passWord
    @Column(name = "password")
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        password = password;
    }

    //repeatPass
    @Column(name = "repeatPass")
    public String getRepeatPass() {
        return repeatPass;
    }
    public void setRepeatPass(String repeatPass) {
        this.repeatPass = repeatPass;
    }



    @Column(name = "token")
    private String token;
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

}
