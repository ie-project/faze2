package ir.asta.training.contacts.dao;

import ir.asta.training.contacts.entities.UserEntity;
import ir.asta.wise.core.datamanagement.ActionResult;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;


@Named("authDAO")
public class AuthDAO {
    @PersistenceContext
    private EntityManager entityManager;

    public UserEntity register(String email, String role, String firstName,
                                             String lastName, String password, String repeatPass,String token){
        UserEntity entity = new UserEntity();
        entity.setEmail(email);
        entity.setRole(role);
        entity.setFirstName(firstName);
        entity.setLastName(lastName);
        entity.setPassword(password);
        entity.setRepeatPass(repeatPass);
        entity.setToken(token);
        entityManager.persist(entity);

        return entity;
    }


    public boolean containsUser(String email){
        Query query = entityManager.createQuery("select e from UserEntity e where e.email = :email");
        query.setParameter("email", email);
        List list = query.getResultList();
        return list.size() > 0;
    }


    public UserEntity checkUserPass(String email,String password){
        Query query = entityManager.createQuery("select e from UserEntity e where e.email =:email and  e.paaaword =: password");
        query.setParameter("email", email).setParameter("password" ,password);
        List<UserEntity> list = query.getResultList();
        if (list.size() > 0)
            return list.get(0);
        return null;
    }

}
