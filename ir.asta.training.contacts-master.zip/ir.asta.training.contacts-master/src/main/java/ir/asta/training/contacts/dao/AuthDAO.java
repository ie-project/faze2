package ir.asta.training.contacts.dao;

import ir.asta.training.contacts.entities.CaseEntity;
import ir.asta.training.contacts.entities.UserEntity;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;


@Named("authDAO")
public class AuthDAO {

    @PersistenceContext
    private EntityManager entityManager;

    public UserEntity register(String email, String role, String firstName,
                               String lastName, String password, String repeatPass,String token){
        UserEntity entity = new UserEntity();
        entity.setEmail(email);
        entity.setRole(role);
        entity.setFirstName(firstName);
        entity.setLastName(lastName);
        entity.setPassword(password);
        entity.setRepeatPass(repeatPass);
        entity.setToken(token);
        entityManager.persist(entity);
        return entity;
    }


    public  CaseEntity setCase(String subject, String whoToSend , String message,String status,String time,String token){
        CaseEntity entity = new CaseEntity();
        entity.setSubject(subject);
        entity.setWhoToSend(whoToSend);
        entity.setMessage(message);
        entity.setStatus(status);
        entity.setTime(time);
        entity.setToken(token);
        entityManager.persist(entity);
        return entity;
    }


    public UserEntity updatePro(UserEntity userEntity){
        entityManager.merge(userEntity);
        return userEntity;
    }

    public boolean containsUser(String email){
        Query query = entityManager.createQuery("select e from UserEntity e where e.email = :email");
        query.setParameter("email", email);
        List list = query.getResultList();
        return list.size() > 0;
    }

    public UserEntity findUser(String email){
        Query query = entityManager.createQuery("select e from UserEntity e where e.email = :email");
        query.setParameter("email",email);
        UserEntity userEntity = (UserEntity) query.getSingleResult();
        return userEntity;
    }

    public UserEntity checkUserPass(String email,String password){
        Query query = entityManager.createQuery("select e from UserEntity e where e.email = :email and  e.password = :password");
        query.setParameter("email", email).setParameter("password" ,password);
        List<UserEntity> list = query.getResultList();

        if (list.size() > 0){
            return list.get(0);
        }

        else
            return null;


    }

    public  List seeCases(String token){
        CaseEntity entity = new CaseEntity();
        Query query = entityManager.createQuery("select c from CaseEntity c where c.whoToSend in " +
                "(select lastName from UserEntity e where e.token = :token )");
        query.setParameter("token", token);
        List list = query.getResultList();
        return list;
    }



    public  List seeAllCases(){
        CaseEntity entity = new CaseEntity();
        Query query = entityManager.createQuery("select c from CaseEntity c " );
        List list = query.getResultList();
        return list;
    }


    public  String seeSender(String token){
        CaseEntity entity = new CaseEntity();
        Query query = entityManager.createQuery("select lastName from UserEntity c where c.token =:token ");
        query.setParameter("token", token);
        String lastName = (String) query.getSingleResult();
        return lastName;
    }


}
