package ir.asta.training.contacts.entities;

import javax.persistence.*;

@Entity
@Table(name = "cases")
public class CaseEntity {


    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }


    @Column(name = "subject")
    private String subject;
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }



    @Column(name = "whoToSend")
    private String whoToSend;
    public String getWhoToSend() {
        return whoToSend;
    }
    public void setWhoToSend(String whoToSend) {
        this.whoToSend = whoToSend;
    }



    @Column(name = "message")
    private String message;
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

}
